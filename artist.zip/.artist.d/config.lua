{
  -- Options handling how inventories are read
  inventories = {
    -- The time between rescanning each inventory
    -- rescan = 10,

    -- A list of ignored inventory peripherals
    -- ignored_names = {},

    -- A list of ignored inventory peripheral types
    ignored_types = {
      "turtle",
      "minecraft:barrel",
      "minecraft:furnace",
    },
  },

  -- Defines chests where you can drop off items
  dropoff = {
    -- The chest names available
    chests = {
      "minecraft:barrel_1",
    },

    -- The time between rescanning dropoff chests when there's been no recent activity
    cold_delay = 0.5,

    -- The time between rescanning dropoff chests when there's been recent activity.
    hot_delay = 0.2,

    -- The chests where user places items(need for crafting handling).
    -- used_by_user = {},
  },

  -- Options related to furnace automation
  furnace = {
    -- The delay between rescanning cold (non-smelting) furnaces
    cold_rescan = 10,

    -- The delay between rescanning hot (smelting) furnaces
    hot_rescan = 5,

    -- A list of ignored furnace peripherals
    -- ignored = {},

    -- A list of furnace types
    types = {},

    -- Possible fuel items
    fuels = {
      "minecraft:charcoal",
      "minecraft:coal",
    },
  },

  -- Automatically dispose of items when you've got too many of them.
  trashcan = {
    -- Peripheral name of the trashcan. If not given, this will attempt to find a turtle running the 'extra/trashcan.lua' script in the Artist repo.
    -- trashcan = nil,

    -- Items which should automatically be trashed. This is a mapping of hashes to the maximum number to keep (e.g. {['minecraft:cobblestone'] = 20 * 1000}
    -- items = {},
  },

  -- Defines a place to pick up items
  pickup = {
    -- The chest from which to pick up items
    chest = "minecraft:barrel_0",
  },
}
